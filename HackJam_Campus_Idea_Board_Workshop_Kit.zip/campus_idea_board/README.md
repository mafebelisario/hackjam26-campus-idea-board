# HackJam '26 — Campus Idea Board Workshop Package

- `starter/` — runnable student project + guided exercises
- `solution/` — complete tested instructor reference
- `docs/SETUP_GUIDE.md` — attendee setup handout
- `docs/INSTRUCTOR_RUN_OF_SHOW.md` — 90-minute facilitation and rehearsal plan

Suggested GitHub repo name: `hackjam26-campus-idea-board`. Create a new GitHub repository and upload the contents of `starter/` as the public student starter. Keep `solution/` in a separate instructor repo or branch if you want to avoid spoiling exercises.

For resource QR codes, use your actual GitHub URL after creating the repository. No fake links are included.
