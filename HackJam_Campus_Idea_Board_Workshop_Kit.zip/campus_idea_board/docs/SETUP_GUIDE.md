# Attendee setup guide — send 24–48 hours before November 9

**Bring:** laptop and charger. Install **Python 3.10+**, a code editor (VS Code recommended), and download/extract the workshop ZIP before arrival.

1. Open the extracted `campus_idea_board/starter` folder in your code editor.
2. Open the terminal in that folder.
3. Windows: `py -m venv .venv` or `python -m venv .venv`.
   macOS/Linux: `python3 -m venv .venv`.
4. Windows: `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`.
   macOS/Linux: `.venv/bin/python -m pip install -r requirements.txt`.
5. Windows: `.\.venv\Scripts\python.exe app.py`.
   macOS/Linux: `.venv/bin/python app.py`.
6. Open **http://127.0.0.1:5000** and confirm you see Campus Idea Board.

**Troubleshooting:** If `python` isn't found, install Python and restart terminal. If port 5000 is busy, stop the other Flask process or edit the port in `app.py` and open the corresponding URL. If `pip` fails, verify Internet access and try again. Do not double-click `index.html`: Flask must serve the page for `/api/ideas` to work.

No GitHub account, paid service, API key, or cloud database is required. SQLite data is local to your laptop.
