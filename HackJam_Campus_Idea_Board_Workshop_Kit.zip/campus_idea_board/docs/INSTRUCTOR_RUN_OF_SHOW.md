# November 9 — Full Stack, Zero Aura Loss

**Goal:** Students understand browser → Flask API → SQLite and leave with a functioning local project.

| Time | Live activity | Milestone |
|---|---|---|
| 0–10 | Introductions, sketch browser → API → DB | Understand full stack |
| 10–20 | Install, open starter, run `python app.py` | App opens locally |
| 20–38 | Edit form/heading/styles, inspect JavaScript submit handler | Frontend understood |
| 38–55 | Explain and test GET/POST endpoints; add/inspect validation | Send/receive JSON |
| 55–68 | Inspect SQLite table, INSERT and SELECT; refresh | Persistent records |
| 68–80 | Use browser Network panel, submit, debug together | End-to-end flow |
| 80–90 | Category filter, upvote, mini-demo and resources | Next steps |

## Presenter plan
- Lead instructor: introduce concepts, live-code from `starter/`, explain requests.
- Co-host: monitor questions, help with Python/terminal errors, keep `solution/` running as fallback.
- Helper(s): assist with setup; do not let one laptop issue block the room.

## Live demo rehearsal
1. Run `python -m unittest discover -s tests -v` from `solution/`.
2. Start `python app.py`, open `http://127.0.0.1:5000`.
3. Submit 'Campus Recycling Tracker', category Off the Grid.
4. Refresh page: idea should persist.
5. Filter by Off the Grid, upvote, inspect browser Network → POST /api/ideas.
6. Keep a second terminal open with the tested solution as a backup (run only one app on port 5000).
7. Screenshot working app and API response; save locally for Wi-Fi/projector fallback.

## Notes
- Demo uses SQLite locally; attendees' ideas are saved on their own computers, not shared across laptops.
- Do not claim a hosted or collaborative board. A shared board requires deployment and a shared database.
- Default Flask debug server is for local development only.
- No external API keys or Internet required after Python dependencies are installed.
- The starter is intentionally runnable; this is guided modification, not 90 minutes of typing a backend from zero.
